package moneytransferapp;

// @@@SNIPSTART money-transfer-project-template-java-shared-constants
public interface Shared {

    static final String MONEY_TRANSFER_TASK_QUEUE = "MONEY_TRANSFER_TASK_QUEUE";
}
// @@@SNIPEND
